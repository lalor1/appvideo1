
import React, { useState, useEffect } from 'react';
import { MediaItem } from '@/api/entities';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trash2, Download, Music } from 'lucide-react';
import Timeline from '../components/editor/Timeline';
import MediaUploader from '../components/editor/MediaUploader';
import Preview from '../components/editor/Preview';
import AudioControl from '../components/editor/AudioControl';
import ExportDialog from '../components/editor/ExportDialog';

export default function Editor() {
  const [items, setItems] = useState([]);
  const [audioItem, setAudioItem] = useState(null);
  const [resolution, setResolution] = useState('1280x720');
  const [isExporting, setIsExporting] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("upload");
  const [lastExport, setLastExport] = useState(null);

  useEffect(() => {
    loadItems();
    loadAudio();
  }, []);

  const loadItems = async () => {
    const mediaItems = await MediaItem.list('order');
    setItems(mediaItems.filter(item => item.type !== 'audio'));
  };

  const loadAudio = async () => {
    const audioItems = await MediaItem.filter({ type: 'audio' });
    if (audioItems.length > 0) {
      setAudioItem(audioItems[0]);
    }
  };

  const handleUpload = async (mediaData) => {
    await MediaItem.create({
      ...mediaData,
      order: items.length
    });
    loadItems();
  };

  const handleReorder = async (newItems) => {
    await Promise.all(
      newItems.map(item => MediaItem.update(item.id, { order: item.order }))
    );
    setItems(newItems);
  };

  const handleRemove = async (id) => {
    await MediaItem.delete(id);
    loadItems();
  };

  const handleClearAll = async () => {
    if (window.confirm('Are you sure you want to remove all items?')) {
      await Promise.all(items.map(item => MediaItem.delete(item.id)));
      loadItems();
    }
  };

  const handleAudioChange = async (newAudioItem) => {
    if (audioItem && audioItem.id) {
      await MediaItem.update(audioItem.id, newAudioItem);
    } else {
      await MediaItem.create(newAudioItem);
    }
    loadAudio();
  };

  const handleAudioDelete = async () => {
    if (audioItem && audioItem.id) {
      await MediaItem.delete(audioItem.id);
      setAudioItem(null);
    }
  };

  const handleExport = () => {
    setIsExporting(true);
    setShowExportDialog(true);
  };
  
  const handleExportComplete = (exportResult) => {
    setIsExporting(false);
    
    if (exportResult && exportResult.fileSize < 5 * 1024 * 1024) {
      alert("Export successful! Note: This is a realistic placeholder for a fully functional video file. Would you like to download the exported file?");
    }
    
    setLastExport(exportResult);
  };
  
  const handleCloseExportDialog = () => {
    setShowExportDialog(false);
    setIsExporting(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <h1 className="text-3xl font-bold text-gray-900">Video Editor</h1>
          <div className="w-full md:w-48">
            <Label>Resolution</Label>
            <Select value={resolution} onValueChange={setResolution}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1080x1920">1080x1920 (Story)</SelectItem>
                <SelectItem value="1080x1080">1080x1080 (Square)</SelectItem>
                <SelectItem value="1280x720">1280x720 (Landscape)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold mb-4">Preview</h2>
              <Preview items={items} resolution={resolution} />
            </div>

            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={handleClearAll}
                disabled={items.length === 0 || isExporting}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
              </Button>
              <Button 
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                onClick={handleExport}
                disabled={items.length === 0 || isExporting}
              >
                <Download className="w-4 h-4 mr-2" />
                {isExporting ? 'Exporting...' : 'Export Video'}
              </Button>
            </div>
            
            {lastExport && !showExportDialog && (
              <div className="bg-gray-50 p-4 rounded-lg text-sm flex items-center justify-between">
                <div>
                  <span className="font-medium">Last Export:</span>
                  <span className="ml-2">{lastExport.filename}</span>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = lastExport.url;
                    link.download = lastExport.filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                  }}
                >
                  <Download className="w-3 h-3 mr-1" />
                  Download Again
                </Button>
              </div>
            )}
          </div>
          
          <div className="space-y-4">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="upload">Upload Media</TabsTrigger>
                <TabsTrigger value="audio" className="flex items-center gap-2">
                  <Music className="w-4 h-4" />
                  Audio
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="upload" className="space-y-4">
                <h2 className="text-xl font-semibold">Add Media</h2>
                <MediaUploader onUpload={handleUpload} selectedResolution={resolution} />
              </TabsContent>
              
              <TabsContent value="audio">
                <AudioControl 
                  audioItem={audioItem}
                  onAudioChange={handleAudioChange}
                  onAudioDelete={handleAudioDelete}
                />
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">Timeline</h2>
          <Timeline
            items={items}
            onReorder={handleReorder}
            onRemove={handleRemove}
          />
        </div>
      </div>
      
      <ExportDialog
        open={showExportDialog}
        onOpenChange={handleCloseExportDialog}
        items={items}
        audioItem={audioItem}
        resolution={resolution}
        onExportComplete={handleExportComplete}
      />
    </div>
  );
}
