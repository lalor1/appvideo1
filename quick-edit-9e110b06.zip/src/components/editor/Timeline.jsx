import React from 'react';
import { Card } from "@/components/ui/card";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Grip, Image as ImageIcon, Video, X, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function Timeline({ items, onReorder, onRemove }) {
  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const startIndex = result.source.index;
    const endIndex = result.destination.index;
    
    const newItems = Array.from(items);
    const [removed] = newItems.splice(startIndex, 1);
    newItems.splice(endIndex, 0, removed);
    
    onReorder(newItems.map((item, index) => ({ ...item, order: index })));
  };

  // Calculate total duration
  const totalDuration = items.reduce((sum, item) => sum + item.duration, 0);
  
  // Format duration for display (minutes:seconds)
  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4">
      {items.length > 0 && (
        <div className="flex justify-between items-center">
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Total Duration: {formatDuration(totalDuration)}
          </Badge>
          <Badge variant="outline">
            {items.length} item{items.length !== 1 ? 's' : ''}
          </Badge>
        </div>
      )}
      
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="timeline">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className="space-y-2"
            >
              {items.map((item, index) => (
                <Draggable key={item.id} draggableId={item.id} index={index}>
                  {(provided) => (
                    <Card
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className="p-3 flex items-center gap-3 bg-white/50 backdrop-blur-sm"
                    >
                      <div {...provided.dragHandleProps} className="cursor-move">
                        <Grip className="w-5 h-5 text-gray-400" />
                      </div>
                      {item.type === 'image' ? (
                        <ImageIcon className="w-5 h-5 text-blue-500" />
                      ) : (
                        <Video className="w-5 h-5 text-purple-500" />
                      )}
                      <div className="flex-1">
                        <div className="text-sm font-medium">
                          {item.type === 'image' ? 'Image' : 'Video'} {index + 1}
                        </div>
                        <div className="text-xs text-gray-500 flex items-center gap-2">
                          <span>Duration: {formatDuration(item.duration)}</span>
                          <span>•</span>
                          <span>Transition: {item.transition}</span>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onRemove(item.id)}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </Card>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
              
              {items.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No media items added yet. Upload files to get started.
                </div>
              )}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}