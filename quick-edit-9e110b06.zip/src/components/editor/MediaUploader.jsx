import React, { useCallback, useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Image as ImageIcon, Video, AlertCircle } from 'lucide-react';
import { UploadFile } from '@/api/integrations';
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function MediaUploader({ onUpload, selectedResolution }) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadCount, setUploadCount] = useState({ current: 0, total: 0 });
  const [mediaType, setMediaType] = useState('image');
  const [duration, setDuration] = useState(3);
  const [transition, setTransition] = useState('none');
  const [error, setError] = useState(null);

  const handleFilesSelect = useCallback(async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    setUploading(true);
    setProgress(0);
    setUploadCount({ current: 0, total: files.length });
    setError(null);

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        // Check if the file type matches the selected media type
        const isImageFile = file.type.startsWith('image/');
        const isVideoFile = file.type.startsWith('video/');
        
        if ((mediaType === 'image' && !isImageFile) || (mediaType === 'video' && !isVideoFile)) {
          continue; // Skip files that don't match the selected type
        }

        const { file_url } = await UploadFile({ file });
        
        // For video files, we'll use their actual duration
        // For image files, we'll use the specified duration
        const actualDuration = mediaType === 'video' ? 
          await getVideoDuration(file_url) : 
          Number(duration);
        
        await onUpload({
          type: mediaType,
          url: file_url,
          duration: actualDuration,
          transition,
          resolution: selectedResolution
        });
        
        setUploadCount(prev => ({ ...prev, current: prev.current + 1 }));
        setProgress(((i + 1) / files.length) * 100);
      }
      
      e.target.value = '';
    } catch (error) {
      console.error('Upload failed:', error);
      setError('An error occurred during upload. Please try again.');
    }
    
    setUploading(false);
  }, [mediaType, duration, transition, selectedResolution, onUpload]);

  // Helper function to get video duration
  const getVideoDuration = (url) => {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.addEventListener('loadedmetadata', () => {
        resolve(video.duration);
      });
      video.src = url;
    });
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="grid gap-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-[150px]">
              <Label>Media Type</Label>
              <Select value={mediaType} onValueChange={setMediaType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="image">
                    <div className="flex items-center gap-2">
                      <ImageIcon className="w-4 h-4" />
                      Images
                    </div>
                  </SelectItem>
                  <SelectItem value="video">
                    <div className="flex items-center gap-2">
                      <Video className="w-4 h-4" />
                      Videos
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-[150px]">
              <Label>Duration for Images (seconds)</Label>
              <Input
                type="number"
                min="1"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                disabled={mediaType !== 'image'}
              />
            </div>

            <div className="flex-1 min-w-[150px]">
              <Label>Transition</Label>
              <Select value={transition} onValueChange={setTransition}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="fade">Fade</SelectItem>
                  <SelectItem value="slide">Slide</SelectItem>
                  <SelectItem value="zoom">Zoom</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {uploading && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-500">
                <span>Uploading {uploadCount.current} of {uploadCount.total} files</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}

          <div className="flex justify-center">
            <input
              type="file"
              accept={mediaType === 'image' ? 'image/*' : 'video/*'}
              onChange={handleFilesSelect}
              className="hidden"
              id="file-upload"
              multiple
            />
            <label htmlFor="file-upload">
              <Button
                disabled={uploading}
                className="w-full cursor-pointer"
                asChild
              >
                <div>
                  <Upload className="w-4 h-4 mr-2" />
                  {uploading ? 'Uploading...' : `Upload Multiple ${mediaType === 'image' ? 'Images' : 'Videos'}`}
                </div>
              </Button>
            </label>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}