import React, { useState, useEffect } from 'react';
import { Card } from "@/components/ui/card";
import { MediaItem } from '@/api/entities';
import { Music } from 'lucide-react';

const aspectRatios = {
  '1080x1920': 'aspect-[9/16]',
  '1080x1080': 'aspect-square',
  '1280x720': 'aspect-video'
};

export default function Preview({ items, resolution }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [transitionType, setTransitionType] = useState('');
  const [nextIndex, setNextIndex] = useState(-1);
  const [audioItem, setAudioItem] = useState(null);
  const [audioElement, setAudioElement] = useState(null);
  const [shouldPlayAudio, setShouldPlayAudio] = useState(false);

  // Load audio item
  useEffect(() => {
    const loadAudio = async () => {
      const audioItems = await MediaItem.filter({ type: 'audio' });
      if (audioItems.length > 0) {
        setAudioItem(audioItems[0]);
      } else {
        setAudioItem(null);
      }
    };
    
    loadAudio();
  }, []);

  // Create or update audio element when audio item changes
  useEffect(() => {
    if (audioItem) {
      const audio = new Audio(audioItem.url);
      audio.loop = true;
      audio.volume = audioItem.volume || 1;
      audio.playbackRate = audioItem.playbackRate || 1;
      setAudioElement(audio);
    } else {
      setAudioElement(null);
    }
    
    return () => {
      if (audioElement) {
        audioElement.pause();
        audioElement.src = '';
      }
    };
  }, [audioItem]);

  // Play/pause audio based on if we have items
  useEffect(() => {
    if (audioElement && items.length > 0) {
      setShouldPlayAudio(true);
    } else {
      setShouldPlayAudio(false);
    }
  }, [audioElement, items]);

  // Control audio playback
  useEffect(() => {
    if (audioElement) {
      if (shouldPlayAudio) {
        const playPromise = audioElement.play();
        if (playPromise !== undefined) {
          playPromise.catch(e => {
            console.log("Audio playback error:", e);
          });
        }
      } else {
        audioElement.pause();
      }
    }
    
    return () => {
      if (audioElement) {
        audioElement.pause();
      }
    };
  }, [audioElement, shouldPlayAudio]);

  useEffect(() => {
    if (!items.length) return;
    
    const item = items[currentIndex];
    const timeout = setTimeout(() => {
      if (currentIndex < items.length - 1) {
        // Store the next index
        const next = currentIndex + 1;
        setNextIndex(next);
        
        // Start transition
        setTransitionType(item.transition);
        setIsTransitioning(true);
        
        // After transition duration, update the current index
        setTimeout(() => {
          setCurrentIndex(next);
          setIsTransitioning(false);
          setTransitionType('');
        }, 1000); // Transition duration
      } else {
        // Loop back to start
        setNextIndex(0);
        setTransitionType(item.transition);
        setIsTransitioning(true);
        
        setTimeout(() => {
          setCurrentIndex(0);
          setIsTransitioning(false);
          setTransitionType('');
        }, 1000);
      }
    }, item.duration * 1000);

    return () => clearTimeout(timeout);
  }, [currentIndex, items]);

  if (!items.length) {
    return (
      <Card className={`${aspectRatios[resolution]} flex items-center justify-center text-gray-400`}>
        Add media to preview
      </Card>
    );
  }

  const currentItem = items[currentIndex];
  const nextItem = nextIndex >= 0 ? items[nextIndex] : null;

  return (
    <Card className={`${aspectRatios[resolution]} overflow-hidden relative`}>
      {/* Current item */}
      {currentItem.type === 'image' ? (
        <img
          src={currentItem.url}
          alt={`Slide ${currentIndex + 1}`}
          className={`absolute inset-0 w-full h-full object-cover transition-all duration-1000 ${
            isTransitioning && (
              transitionType === 'fade' ? 'opacity-0' :
              transitionType === 'slide' ? '-translate-x-full' :
              transitionType === 'zoom' ? 'scale-150 opacity-0' : ''
            )
          }`}
        />
      ) : (
        <video
          src={currentItem.url}
          autoPlay
          muted
          loop={items.length === 1}
          className={`absolute inset-0 w-full h-full object-cover transition-all duration-1000 ${
            isTransitioning && (
              transitionType === 'fade' ? 'opacity-0' :
              transitionType === 'slide' ? '-translate-x-full' :
              transitionType === 'zoom' ? 'scale-150 opacity-0' : ''
            )
          }`}
        />
      )}

      {/* Next item (shown during transitions) */}
      {isTransitioning && nextItem && (
        <div className={`absolute inset-0 transition-all duration-1000 ${
          transitionType === 'slide' ? 'translate-x-full opacity-100' : 'opacity-100'
        }`}>
          {nextItem.type === 'image' ? (
            <img
              src={nextItem.url}
              alt={`Next slide`}
              className="w-full h-full object-cover"
            />
          ) : (
            <video
              src={nextItem.url}
              autoPlay
              muted
              className="w-full h-full object-cover"
            />
          )}
        </div>
      )}

      {/* Audio indicator */}
      {audioItem && (
        <div className="absolute bottom-2 right-2">
          <div className="bg-black/50 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
            <Music className="w-3 h-3" />
            {audioItem.playbackRate !== 1 ? `${audioItem.playbackRate}x` : ''}
          </div>
        </div>
      )}
    </Card>
  );
}