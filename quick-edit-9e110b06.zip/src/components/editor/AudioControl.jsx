import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Upload, Play, Pause, Volume2, Music, FastForward, Trash2 } from 'lucide-react';
import { UploadFile } from '@/api/integrations';

export default function AudioControl({ audioItem, onAudioChange, onAudioDelete }) {
  const [uploading, setUploading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(audioItem?.playbackRate || 1);
  const [volume, setVolume] = useState(audioItem?.volume || 1);
  const audioRef = useRef(null);

  useEffect(() => {
    if (audioRef.current) {
      if (audioItem && audioItem.url) {
        audioRef.current.src = audioItem.url;
        audioRef.current.load();
      }
      
      audioRef.current.onloadedmetadata = () => {
        setDuration(audioRef.current.duration);
        if (onAudioChange && audioItem) {
          onAudioChange({
            ...audioItem,
            duration: audioRef.current.duration
          });
        }
      };
      
      audioRef.current.ontimeupdate = () => {
        setCurrentTime(audioRef.current.currentTime);
      };
      
      audioRef.current.onended = () => {
        setIsPlaying(false);
      };
    }
  }, [audioItem?.url]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
      if (audioItem) {
        onAudioChange({
          ...audioItem,
          playbackRate
        });
      }
    }
  }, [playbackRate]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      if (audioItem) {
        onAudioChange({
          ...audioItem,
          volume
        });
      }
    }
  }, [volume]);

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.includes('audio')) return;
    
    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      
      const audio = new Audio();
      audio.src = file_url;
      
      // Wait for metadata to load to get duration
      await new Promise(resolve => {
        audio.onloadedmetadata = resolve;
      });
      
      const newAudioItem = {
        type: 'audio',
        url: file_url,
        duration: audio.duration,
        order: 0,
        playbackRate: 1,
        volume: 1,
        resolution: "1280x720", // Not relevant for audio but required by schema
      };
      
      onAudioChange(newAudioItem);
      e.target.value = '';
    } catch (error) {
      console.error('Audio upload failed:', error);
    }
    setUploading(false);
  };

  const togglePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const changePlaybackRate = (value) => {
    setPlaybackRate(value[0]);
  };

  const changeVolume = (value) => {
    setVolume(value[0]);
  };

  if (!audioItem) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Music className="w-5 h-5" />
            Background Audio
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center py-4">
            <input
              type="file"
              accept="audio/*"
              onChange={handleFileSelect}
              className="hidden"
              id="audio-upload"
            />
            <label htmlFor="audio-upload">
              <Button
                disabled={uploading}
                className="cursor-pointer"
                asChild
              >
                <div>
                  <Upload className="w-4 h-4 mr-2" />
                  {uploading ? 'Uploading...' : 'Upload Audio'}
                </div>
              </Button>
            </label>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5" />
            Background Audio
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onAudioDelete()}
            className="text-gray-400 hover:text-red-500"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <audio ref={audioRef} className="hidden" />
        
        <div className="space-y-4">
          {/* Audio player controls */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                size="icon"
                onClick={togglePlayPause}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </Button>
              <div className="text-sm text-gray-500">
                {formatTime(currentTime)} / {formatTime(duration)}
              </div>
            </div>
            
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-500 transition-all duration-300"
                style={{ width: `${(currentTime / duration) * 100}%` }}
              />
            </div>
          </div>
          
          {/* Playback rate control */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-2">
                <FastForward className="w-4 h-4" />
                Playback Speed
              </Label>
              <span className="text-sm font-medium">{playbackRate.toFixed(1)}x</span>
            </div>
            <Slider
              value={[playbackRate]}
              min={0.5}
              max={2}
              step={0.1}
              onValueChange={changePlaybackRate}
            />
            <div className="grid grid-cols-3 text-xs text-gray-500">
              <div>Slower (0.5x)</div>
              <div className="text-center">Normal (1.0x)</div>
              <div className="text-right">Faster (2.0x)</div>
            </div>
          </div>
          
          {/* Volume control */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="flex items-center gap-2">
                <Volume2 className="w-4 h-4" />
                Volume
              </Label>
              <span className="text-sm font-medium">{Math.round(volume * 100)}%</span>
            </div>
            <Slider
              value={[volume]}
              min={0}
              max={1}
              step={0.01}
              onValueChange={changeVolume}
            />
            <div className="grid grid-cols-2 text-xs text-gray-500">
              <div>Mute (0%)</div>
              <div className="text-right">Full (100%)</div>
            </div>
          </div>

          {/* Option to upload new audio */}
          <div className="pt-2">
            <input
              type="file"
              accept="audio/*"
              onChange={handleFileSelect}
              className="hidden"
              id="audio-upload-replace"
            />
            <label htmlFor="audio-upload-replace">
              <Button
                variant="outline"
                disabled={uploading}
                className="w-full cursor-pointer"
                asChild
              >
                <div>
                  <Upload className="w-4 h-4 mr-2" />
                  {uploading ? 'Uploading...' : 'Replace Audio'}
                </div>
              </Button>
            </label>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}